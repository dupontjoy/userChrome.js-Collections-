
//2015.06.12 19:00 某些網站要訪問才會顯示favicon，現補全
//2015.04.02 12:00 修复36版问题

var Config = getMStr(function(){
	var sites;
/*
搜索導航
	Google, https://www.google.com/ncr, https://www.google.com/favicon.ico#-moz-resolution=16,16
	百度, https://www.baidu.com/, https://www.baidu.com/favicon.ico#-moz-resolution=16,16
	Bing, http://global.bing.com/?FORM=HPCNEN&setmkt=en-us&setlang=en-us, http://global.bing.com/s/a/bing_p.ico#-moz-resolution=16,16
新聞資訊
	Pulse, http://www.linkedin.com/today/?trk=nav_responsive_sub_nav_pulse, http://s.c.lnkd.licdn.com/scds/common/u/images/logos/favicons/v1/favicon.ico#-moz-resolution=16,16
	CNN,  http://www.cnn.com/
	Economist,  http://www.economist.com/
社交論譠
	Facebook, https://www.facebook.com/, https://fbstatic-a.akamaihd.net/rsrc.php/yl/r/H3nktOa7ZMg.ico#-moz-resolution=16,16
	Twitter, https://twitter.com/, https://abs.twimg.com/favicons/favicon.ico#-moz-resolution=16,16
知也無涯
  益書網, http://www.kindbook.cn/
  扇貝, http://www.shanbay.com/, http://www.shanbay.com/favicon.ico#-moz-resolution=16,16
影音娱樂
	Youtube, https://www.youtube.com/, https://s.ytimg.com/yts/img/favicon_144-vflWmzoXw.png
	迅雷雲播, http://vod.xunlei.com/
	網易雲音樂, http://music.163.com/
郵箱網盤
	163郵箱, http://email.163.com/, http://email.163.com/favicon.ico#-moz-resolution=16,16
	爲知筆記, https://note.wiz.cn/web

*/
});

// myNewTab 文件夹的相对于配置文件的路径
var newTabDirPath = "extensions\\userChromeJS@mozdev.org\\content\\myNewTab";
// 图片存储的文件夹名字，相对于上面的路径
var bingImageDir = "必应美图";

var useBingImage = 1;  // 1：使用 bing 的背景图片？ 0：不使用
var updateImageTime = 0.1;  // 更新 bing 背景图片的间隔（单位：天）
var bingImageSize = 0;  // bing 图片的尺寸，0 为默认的 1366x768，1 为 1920x1080（大很多，可能会加载慢些）
var bingMaxHistory = 10; // 最大历史天数，10天内应该有个好看的吧？

var isNewTab = 0;  // 1：强制新标签页打开 0：默认

/*
  以下不要修改
 */

// 解析后的数据结构，开发时查看用
// var data = {
// 	"新闻资讯": [
// 		{ name: "Feedly", url: "http://cloud.feedly.com/", imgSrc: "img/feedly.ico" },
// 	],
// 	"在线应用": [
// 		{ name: "翻译", url: "https://translate.google.de/#auto/zh-CN/", imgSrc: "img/gtrans.ico" },
// 	],
// };

"use strict";

var Ci = Components.interfaces;
var Cc = Components.classes;
var Cu = Components.utils;
 
Cu.import("resource://gre/modules/PlacesUtils.jsm");
Cu.import("resource://gre/modules/Services.jsm");

var NewTab = {
	localLinkRegExp: /^[a-z]:\\[^ ]+$/i,  // windows 路径
	get prefs() {
	    delete this.prefs;
	    return this.prefs = Services.prefs.getBranch("myNewTab.");
	},

	init: function() {
		var table = document.getElementById("navtable");
		if (table.children.lenth > 0) {
			return;
		}

		// 获取 bing 中国主页的背景图片
		var data = this.loadSetting();
		if (useBingImage) {
			if (data.backgroundImage && (new Date().getTime() - data.lastCheckTime) < updateImageTime * 24 * 3600 * 1000) {
				document.body.style.backgroundImage = 'url(' + data.backgroundImage + ')';
			} else {
				this.getBingImage(0);
			}
		}

		var siteData = this.parseDataText(Config.sites);
		// console.log(siteData);
		
		var tr, type;
		for(type in siteData) {
			tr = this.buildTr(type, siteData[type]);
			table.appendChild(tr);
		}
	},
	loadSetting: function() {
		var jsonData;
		try {
			jsonData = this.prefs.getCharPref("jsonData");
			jsonData = JSON.parse(jsonData);
		} catch(e) {
			jsonData = {}
		}

		return jsonData;
	},
	setSetting: function(data){
		try {
			this.prefs.setCharPref("jsonData", JSON.stringify(data));
		} catch(e) {}
	},
	getBingImage: function(idx) {
		var self = this;
		var url = 'http://global.bing.com/HPImageArchive.aspx?format=js&idx=' + idx + '&n=1&nc=' + new Date().getTime() + '&pid=hp&scope=web';
		var xhr = new XMLHttpRequest();
		xhr.open('GET', url, true);
		xhr.onload = function() {
			var data = JSON.parse(xhr.responseText);

			var name = data.images[0].copyright;
			var enddate = parseInt(data.images[0].enddate);
			var imageUrl = data.images[0].url;

			// 处理图片地址
			if (bingImageSize) {
				imageUrl = imageUrl.replace('1366x768', '1920x1080');
			}
			if (!imageUrl.startsWith('http')) {
				imageUrl = 'http://global.bing.com' + imageUrl;
			}

			// 本地图片
			var file = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
			/*file.appendRelativePath(newTabDirPath);*///位置調到Profile下
			file.appendRelativePath(bingImageDir)
			file.appendRelativePath(enddate + '-' + name.replace(/(\s|\(.*?\))/g, '') + ".jpg")

			// 转为本地路径
			var filePath = 'file:///' + encodeURI(file.path.replace(/\\/g, '/'));
			// 设置背景图片并保存设置
			var setAndSave = function(filePath) {
				document.body.style.backgroundImage = 'url(' + filePath + ')';
				self.setSetting({
					lastCheckTime: new Date().getTime(),
					backgroundImage: filePath
				});
			};

			if (file.exists()) {
				setAndSave(filePath);
				return;
			}

			//下载图片
			var t = new Image();
			t.src = imageUrl;
			t.onload = function() {
				try {
					file.create(Ci.nsIFile.NOMAL_FILE_TYPE, 0777)
					Cc["@mozilla.org/embedding/browser/nsWebBrowserPersist;1"].createInstance(Ci.nsIWebBrowserPersist)
						.saveURI(Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService).newURI(imageUrl, null, null), null, null, null, null, null, file, null);
				} catch (err) {
					// alert(err)
				}
				setTimeout(function(){
					setAndSave(filePath);
				}, 100);
			}
		};
		xhr.send(null);
	},
	parseDataText: function (text) {
		var data = [],
			lines, line, arr, type;

		// 处理下
		text = text.replace(/，/g, ',');

		lines = text.split('\n');
		for (var i = 0, l = lines.length; i < l; i++) {
			line = lines[i].trim();
			if (!line) continue;
			arr = line.split(',');
			if (arr.length == 1) {
				type = arr[0];
				data[type] = [];
			} else {
				data[type].push({
					name: arr[0].trim(),
					url: arr[1] ? arr[1].trim() : null,
					imgSrc: arr[2] ? arr[2].trim() : null
				});
			}
		}
		return data;
	},
	buildTr: function (type, sites) {
		var tr = document.createElement('tr'),
			th = document.createElement('th'),
			span = document.createElement('span'),
			site, td, a, img, textNode, path;
		
		// 添加分类
		span.innerHTML = type;
		th.appendChild(span);
		tr.appendChild(th);

		// 添加站点
		for (var i = 0, l = sites.length; i < l; i++) {
			site = sites[i];

			td = document.createElement('td');
			a = document.createElement('a');
			img = document.createElement('img');
			textNode = document.createTextNode(site.name);

			a.setAttribute('title', site.name);
			path = this.handleUrl(site.url);
			if (path) {
				a.setAttribute('href', 'javascript:;');
				a.setAttribute('localpath', path);
				a.addEventListener('click', function(e){
					var fullpath = e.target.getAttribute('localpath');
					NewTab.exec(fullpath);
				}, false);

				site.exec = path;
			} else {
				a.setAttribute('href', site.url);
			}

			if (isNewTab) {
				a.setAttribute('target', '_blank');
			}
			
			// 设置图片的属性
			img.width = 16;
			img.height = 16;
			if (site.imgSrc) {
				img.src = site.imgSrc;
			} else {
				this.setIcon(img, site);
			}

			a.appendChild(img);
			a.appendChild(textNode);
			td.appendChild(a);
			tr.appendChild(td);
		}
		return tr;
	},
	handleUrl: function (urlOrPath) {
		if (urlOrPath.indexOf('\\') == 0) {  // 相对 firefox 路径文件
			urlOrPath = urlOrPath.replace(/\//g, '\\').toLocaleLowerCase();
			var profileDir = Cc['@mozilla.org/file/directory_service;1'].getService(Ci.nsIProperties)
					.get("ProfD", Ci.nsILocalFile).path;
			return profileDir + urlOrPath;
		} else if (this.localLinkRegExp.test(urlOrPath)) {
			return urlOrPath;
		}

		return false;
	},
	exec: function (path) {
		var file = Cc['@mozilla.org/file/local;1'].createInstance(Ci.nsILocalFile);
		file.initWithPath(path);
		if (!file.exists()) {
		    alert('路径并不存在：' + path);
		    return;
		}
		file.launch();
	},
	setIcon: function (img, obj) {
		if (obj.exec) {
		    var aFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
		    try {
		        aFile.initWithPath(obj.exec);
		    } catch (e) {
		        return;
		    }
		    if (!aFile.exists()) {
		        img.setAttribute("disabled", "true");
		    } else {
		        var fileURL = Services.io.getProtocolHandler("file").QueryInterface(Ci.nsIFileProtocolHandler).getURLSpecFromFile(aFile);
		        img.setAttribute("src", "moz-icon://" + fileURL + "?size=16");
		    }
		    return;
		}

		var uri, iconURI;
		try {
		    uri = Services.io.newURI(obj.url, null, null);
		} catch (e) { }
		if (!uri) return;

		PlacesUtils.favicons.getFaviconDataForPage(uri, {
		    onComplete: function(aURI, aDataLen, aData, aMimeType) {
		        try {
    			    // javascript: URI の host にアクセスするとエラー
    			    img.setAttribute("src", aURI && aURI.spec?
    			        "moz-anno:favicon:" + aURI.spec:
    			        "moz-anno:favicon:" + uri.scheme + "://" + uri.host + "/favicon.ico");
    			} catch (e) { }
		    }
		});
	}
};

window.addEventListener('load', function(){
	NewTab.init();
}, false);

//随机背景
function randomImage(){
	var n = Math.floor(Math.random() * bingMaxHistory);
	NewTab.getBingImage(n);
}

//定位文件目录
function openDir() {
	var dsFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	dsFile.appendRelativePath(newTabDirPath);
	dsFile.reveal();
}

//编辑配置
function edit() {
	var dsFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	dsFile.appendRelativePath(newTabDirPath);
	dsFile.append('index.js');
	var cPath = dsFile.path;

	var editor;
	try {
	    editor = Services.prefs.getComplexValue("view_source.editor.path", Ci.nsILocalFile);
	} catch(e) {}
	
	if (!editor || !editor.exists()) {
	    if (showError) {
	        alert("编辑器的路径未设置!!!\n请设置 view_source.editor.path");
	        var url = "about:config?filter=view_source.editor.path";
	        openLinkIn(url, "tab", { inBackground: false});
	    }
	    return;
	}

	var process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
	try {
		process.init(editor);
		process.run(false, [cPath], 1);
	} catch(e) {}
}


// 从函数中获取多行注释的字符串
function getMStr(fn) {
    var fnSource = fn.toString();
    var ret = {};
    fnSource = fnSource.replace(/^[^{]+/, '');
    // console.log(fnSource);
    var matched;
    var reg = /var\s+([$\w]+)[\s\S]*?\/\*([\s\S]+?)\*\//g;
    while (matched = reg.exec(fnSource)) {
        // console.log(matched);
        ret[matched[1]] = matched[2];
    };
    
    return ret;
}