﻿// 导航站点设置
var Config = getMStr(function(){
    var sites;
/*
搜索導航
	Google, https://www.google.com/ncr, https://www.google.com/favicon.ico#-moz-resolution=16,16
	百度, https://www.baidu.com/, https://www.baidu.com/favicon.ico#-moz-resolution=16,16
	Bing, http://global.bing.com/?FORM=HPCNEN&setmkt=en-us&setlang=en-us, http://global.bing.com/s/a/bing_p.ico#-moz-resolution=16,16
新聞資訊
	Pulse, http://www.linkedin.com/today/?trk=nav_responsive_sub_nav_pulse, http://s.c.lnkd.licdn.com/scds/common/u/images/logos/favicons/v1/favicon.ico#-moz-resolution=16,16
	CNN,  http://www.cnn.com/
	Economist,  http://www.economist.com/
社交論譠
	Facebook, https://www.facebook.com/, https://fbstatic-a.akamaihd.net/rsrc.php/yl/r/H3nktOa7ZMg.ico#-moz-resolution=16,16
	Twitter, https://twitter.com/, https://abs.twimg.com/favicons/favicon.ico#-moz-resolution=16,16
知也無涯
  益書網, http://www.kindbook.cn/
  扇貝, http://www.shanbay.com/, http://www.shanbay.com/favicon.ico#-moz-resolution=16,16
影音娱樂
	Youtube, https://www.youtube.com/, https://s.ytimg.com/yts/img/favicon_144-vflWmzoXw.png
	迅雷雲播, http://vod.xunlei.com/
	網易雲音樂, http://music.163.com/
郵箱網盤
	163郵箱, http://email.163.com/, http://email.163.com/favicon.ico#-moz-resolution=16,16
	爲知筆記, https://note.wiz.cn/web
*/
});
// 从函数中获取多行注释的字符串
function getMStr(fn) {
    var fnSource = fn.toString();
    var ret = {};
    fnSource = fnSource.replace(/^[^{]+/, '');
    // console.log(fnSource);
    var matched;
    var reg = /var\s+([$\w]+)[\s\S]*?\/\*([\s\S]+?)\*\//g;
    while (matched = reg.exec(fnSource)) {
        // console.log(matched);
        ret[matched[1]] = matched[2];
    };
    
    return ret;
}