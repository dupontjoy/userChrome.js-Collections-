﻿// 导航站点设置
var Config = getMStr(function(){
    var sites;
/*
社区交流
	QQ空间, http://qzone.qq.com/, img/qqzone.ico
	人人, http://www.renren.com/, img/rr.ico
	远景论坛, http://bbs.pcbeta.com/, img/pcbeta.ico
	看小说, http://booklink.me/, img/booklink.ico
	微博, http://weibo.com/, img/sina.ico
	赢政论坛, http://yingzheng.com/forum.php?mod=forumdisplay&fid=10, img/yingzheng.ico
	极限社区, http://bbs.themex.net/, img/themex.ico
	豆瓣, http://www.douban.com/, img/douban.ico
	贴吧, http://tieba.baidu.com/, img/tieba.png
	天涯社区, http://focus.tianya.cn/, img/tianya.ico
	猫扑, http://www.mop.com/, img/mop.ico
	DoPusBBS, http://resource.dopus.com/, img/dopus.png
	软媒论坛, http://bbs.ithome.com/, img/ithome.ico
	深度论坛, http://bbs.shendu.com/windows/, img/shendu.png
	凯迪社区, http://club.kdnet.net/, img/kdnet.ico
	花粉俱乐部, http://www.huafans.cn/forum-114-1.html, img/huafans.ico
	电脑软硬件, http://bbs.ngacn.cc/thread.php?fid=334&page=1, img/ngacn.png
	新源代论坛, http://www.xydai.cn/index.php, img/xydai.png
	小偷程序, http://www.vxiaotou.com/, img/vxiaotou.png
	无忧启动，http://bbs.wuyou.net/forum.php, img/wuyou.ico
新闻资讯
	网易,  http://www.163.com/,  img/163.ico
	太平洋,  http://www.pconline.com.cn/, img/pconline.ico
	凤凰网,  http://www.ifeng.com/, img/ifeng.ico
	环球网,  http://www.huanqiu.com/, img/huanqiu.ico
	网址导航,  http://gps.sunbox.cc/, img/sunbox.ico
	欧洲时报,  http://www.oushinet.com/, img/oushinet.png     
	中国时评网,  http://www.crntt.com/, img/crntt.ico
	星岛环球网,  http://www.stnn.cc/, img/stnn.ico
	联合早报网,  http://www.zaobao.com/, img/zaobao.ico
	香港文汇网,  http://www.wenweipo.com/, img/wenweipo.png
	奇闻奇图网,  http://www.qwqt.net/, img/qwqt.ico
	Vista看天下,  http://www.vistastory.com/, img/vistastory.ico
	中华网军事,  http://military.china.com/, img/china.png
	天涯看楼主,  http://www.tianya200.com/, img/tianya.ico
影视播放
   优酷视频, http://www.youku.com/, img/youku.ico
	爱奇艺, http://www.iqiyi.com/, img/iqiyi.ico
	迅雷看看, http://www.kankan.com/, img/kankan.ico
	风云直播, http://www.fengyunzhibo.com/, img/fengyunzhibo.ico
  BT天堂, http://www.bttiantang.com/, img/bttiantang.png
	炫电影, http://www.xuandy.com/, img/xuandy.jpg
	我爱P2P, http://oabt.org/, img/oabt.png
	EZTV资源, http://eztv.it/, img/eztv.ico
	电影天堂, http://www.dygod.net/, img/dy2018.png
	曹柳社区, http://t66y.com/, img/man.png
	丫丫下载站, http://www.yayaxz.com/, img/yayaxz.png
	老调网资源, http://www.bestxl.com/, img/bestxl.png
	记录片下载,   http://www.opclass.com/, img/opclass.ico
高清站点
	CHD, http://chdbits.org/, img/chdbits.png
	HDW， http://hdwing.com/, img/hdwing.png
	TTG， http://totheglory.im/, img/ttg.png
	CMCT， https://hdcmct.org/, img/cmct.png
	HDS， http://hdsky.me/, img/hdsky.png
	HDF, http://pt.hd4fans.org/, img/hd4fans.png
影像设计
	色影无忌, http://ww.xitek.com/, img/xitek.ico
	蜂鸟网, http://www.fengniao.com/, img/fengniao.ico
	POCO, http://www.poco.cn/, img/poco.ico
	网易摄影, http://pp.163.com/square/, img/pp163.png
    DeviantArt, http://www.deviantart.com/, img/deviantart.PNG
	Pixiv, http://www.pixiv.net/, img/Pixiv.ico
	Leica中文, http://www.leica.org.cn/, img/leica.png
	搜索图标, http://findicons.com/, img/findicons.ico 
	趣字体, http://www.qiuziti.com/, img/qiuziti.ico
	imgBox, http://imgbox.com/, img/imgbox.ico
	找字网,   http://www.zhaozi.cn/, img/zhaozi.png
	好图网,   http://www.haotu.net/, img/haotu.png
	看图找字体, http://www.qiuziti.com/, img/qiuziti.ico
	圆点视线, http://www.apoints.com/, img/apoints.gif
	阿里字库, http://www.iconfont.cn/repositories/10, img/iconfont.png
	UI中国, http://www.ui.cn/list.php?scat=0&f=&cat=2, img/ui.png
	搜索图标, http://www.easyicon.net/, img/easyicon.ico
	配色大词典, http://www.colordic.org/h/, img/colordic.ico
	叶子树酷站, http://www.webshu.net/cool/, img/webshu.gif
网购生活
	淘宝， http://www.taobao.com/, img/alipay.ico
	什么值得买, http://www.smzdm.com/, img/smzdm.ico
	美团, http://www.meituan.com/, img/meituan.ico 
	亚马逊, http://www.amazon.cn/ref=gno_logo, img/amazom.ico
	京东, http://www.jd.com/, img/jd.ico
	易讯, http://www.yixun.com/, img/yixun.ico
	支付宝， https://www.alipay.com/, img/alipay.ico
	工商银行, https://mybank.icbc.com.cn/icbc/perbank/index.jsp, img/icbc.png 
	建设银行, http://www.ccb.com/cn/jump/personal_loginbank.html, img/ccb.ico
	招商银行, https://pbnj.ebank.cmbchina.com/CmbBank_GenShell/UI/GenShellPC/Login/Login.aspx, img/CMBB.ico
	火车票， http://www.12306.cn/, img/12306.ico
	去哪网, http://www.qunar.com/, img/qunar.png
资源收藏
	ZD423, http://www.zdfans.com/, img/zd423.ico
	绿软家园, http://www.downg.com/, img/lrshare.ico
	绿软分享, http://www.lrshare.com/, img/lrshare.ico
	便携绿软, http://www.portablesoft.org/ , img/portableapps.ico
	机锋论坛, http://bbs.gfan.com/, img/gfan.ico
	炫音论坛, http://bbs.musicool.cn/, img/musicool.ico
	海盗湾, https://thepiratebay.se/, img/thepiratebay.ico.bmp
	游侠论坛, http://game.ali213.net/, img/ali213.ico
	Wallbase, http://wallbase.cc/toplist, img/wallbase.gif
	西西软件, http://www.cr173.com/, img/cr173.jpg
	天天软件, http://www.tt7z.com/, img/ttrar.ico
	流风清音, http://haojian138.blog.163.com/, img/haojian138.jpg
	Kickass, http://kickass.to/, img/kickass.ico
	小众, http://www.appinn.com/, img/xiaoz.png
	异次元, http://www.iplaysoft.com/, img/yiciyuan.png
	PT80, http://www.pt80.net/, img/pt80.png
在线应用
	网评防和谐, http://fanghexie.sinaapp.com/, img/fanghexie.ico
    浮屠塔, http://www.fututa.com/, img/fututa.png
	生肖星座, http://astros.duapp.com/, img/xingzuo.ico
	万年历, http://wannianli.duapp.com/v4/, img/wan.png
	外汇牌价, http://forex.jrj.com.cn/list/whbjList.shtml, img/jrj.png
	网盘搜索, http://so.baiduyun.me/, img/baiduyun.ico
	谷歌翻译, https://translate.google.de/#auto/zh-CN/, img/gtrans.ico
	谷歌地图, https://www.google.de/maps/, img/gmaps.ico
	威盘上传, http://www.vdisk.cn/api/webupload, img/vdisk.ico
	查快递, http://www.kiees.cn/, img/kiees.ico
	Pr0xyN, http://www.proxynova.com/, img/proxy.ico
	站长工具, http://tool.oschina.net/, img/tools.ico
	百度云, http://pan.baidu.com/disk/home?, img/baiduyun.ico
	TinyPNG, https://tinypng.com/, img/tinypng.ico
	live邮箱, http://home.live.com/, img/live.ico
火狐专区
	卡饭火狐, http://bbs.kafan.cn/forum-215-1.html, img/kafan.ico
	Mozest, https://g.mozest.com/, img/mozest.png
	火狐吧, http://tieba.baidu.com/f?ie=utf-8&kw=firefox, img/tieba.png
	官方 FTP, http://ftp.mozilla.org/pub/mozilla.org/firefox/, img/ftp.ico
	Greasyfork, https://greasyfork.org/scripts, img/userscript.png
	Fox扩展, https://addons.mozilla.org/zh-CN/firefox/, img/addons.png
	火狐范, http://www.firefoxfan.com/, img/huwuku.ico
	附加组件, https://addons.mozilla.org/zh-CN/firefox/, img/addons.ico
	台湾社群, http://moztw.org/, img/moztw.png
	水木社区, http://www.newsmth.net/nForum/?_escaped_fragment_=article/Firefox/102939#!board/Firefox, img/newsmth.ico
	阳光盒子，http://sunbox.cc/，img/sunbox.png
综合辅助
	谷歌首页, https://www.google.de/, img/google.ico
	百度首页, http://www.baidu.com/, img/baidu.ico
	必应首页, http://www.bing.com/, img/bing.ico
	维基百科, https://de.wikipedia.org/wiki/Wikipedia:Hauptseite, img/wiki.ico
	搜索图标, http://www.easyicon.net/, img/easyicon.ico
	网盘屋,   http://www.wangpanwu.com/, img/wangpanwu.png
	51搜BT, http://51sobt.com/, img/51sobt.png
	乐搜资源,   http://www.lesou.org/, img/lesou.png
	种子搜索,   http://torrentproject.com/, img/torrentproject.ico
	SimpleCD,   http://www.simplecd.me/, img/simplecd.png
	ed2000,   http://www.ed2000.com/, img/ed2kers.png
	ed2kers,   http://www.ed2kers.com/, img/ed2kers.png
	种子转磁力,   http://www.btspread.com/, img/btspread.ico
	
海外网站
	Google, https://74.125.0.193/, img/google.ico
	FaceBook, https://www.facebook.com/, img/FaceBook.ico
      Feedly,  https://cloud.feedly.com/, img/feedly.ico
	Youtube, https://www.youtube.com/, img/youtube.ico
	Twitter, https://twitter.com/, img/twitter.ico
	维基百科, https://zh.wikipedia.org/, img/wikipedia.ico
*/
});
// 从函数中获取多行注释的字符串
function getMStr(fn) {
    var fnSource = fn.toString();
    var ret = {};
    fnSource = fnSource.replace(/^[^{]+/, '');
    // console.log(fnSource);
    var matched;
    var reg = /var\s+([$\w]+)[\s\S]*?\/\*([\s\S]+?)\*\//g;
    while (matched = reg.exec(fnSource)) {
        // console.log(matched);
        ret[matched[1]] = matched[2];
    };
    
    return ret;
}